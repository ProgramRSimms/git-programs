package application.model;
/**
 * @author Roderick Simms (aak759)
 * UTSA CS 3443 - Lab 4
 * Fall 2021
 */

//import java.io.BufferedReader;
import java.io.*;
import java.util.*;

/*
 * Crossword class and class variables for string array of words for both csv files
 */
public class Crossword {
	public ArrayList<String> down = new ArrayList<String>();
	public ArrayList<String> across = new ArrayList<String>();
	/*
	 * A class method called loadData will take in 
	 * 2 file names and read the clues from the files. 
	 * You may decide how you would like to store the 
	 * clues and their corresponding answers.
	 */
	public void loadData(String down, String across){
		try{
		BufferedReader brDown= new BufferedReader(new FileReader(down));
		BufferedReader brAcross = new BufferedReader(new FileReader(across));
		
		String word;
		while (brDown.readLine() != null){
			//remove the commas from the down.csv file
			word = brDown.readLine().replace(",", " ");
			this.down.add(word);
		}
		brDown.close();
		
		while (brAcross.readLine() != null){
			//remove the commas from the across.csv file
			word = brAcross.readLine().replace(",", " ");
			this.across.add(word);
		}
		brAcross.close();
		}
		catch(Exception e){
		System.out.println(e.getStackTrace());
		}
	}
	/**
	 * @return the across
	 */
	public ArrayList<String> getAcross() {
		return across;
	}
	/**
	 * @param across the across to set
	 */
	public void setAcross(ArrayList<String> across) {
		this.across = across;
	}
	/**
	 * @return the down
	 */
	public ArrayList<String> getDown() {
		return down;
	}
	/**
	 * @param down the down to set
	 */
	public void setDown(ArrayList<String> down) {
		this.down = down;
	}

	
}
