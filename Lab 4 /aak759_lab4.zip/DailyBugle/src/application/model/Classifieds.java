package application.model;
/**
 * @author Roderick Simms (aak759)
 * UTSA CS 3443 - Lab 4
 * Fall 2021
 */


import java.io.*;
import java.util.*;

/*
 * Classified ad class and class variables for using the Advertisement objs of data to fill the ad quadrants in the scene boxes
 */
public class Classifieds {
	public ArrayList<Advertisement> ads = new ArrayList<Advertisement>();
	int count = 0;

	public Classifieds(Advertisement arr[], int count){
		for (int i = 0; i < count; i++){
			this.ads.add(arr[i]);
		}
		this.count = count;
	}

	public Classifieds(int count){
		this.count = count;
	}
	/*
	 * will have an object method called loadAds which takes in a file name 
	 * and stores the data as Advertisement objects. The class Advertisement.
	 * java will have fields for a title, phone number, a boolean for “full 
	 * time work” (if this is false, the position is part-time), a date when 
	 * the ad was posted, and a name for the individual posting the ad.
	 */
	public void loadAds(String fileName){
	
		try{
			BufferedReader file = new BufferedReader(new FileReader(fileName));
			//error check
			while (file.readLine() != null){
			String line = file.readLine();
			String splitString[] = line.split(",");
			boolean isFullTime;
			if (splitString[1].toLowerCase().equals("full")){
				isFullTime = true;
			}
			else{
				isFullTime = false;
			}
			//format ad to display in rectangles
			/*
			 * format csv example: title,Full,phone number,name,date
			 */
			this.ads.add(new Advertisement(splitString[0], isFullTime, splitString[2],  splitString[3], splitString[4]));
			this.count++;
			}
			file.close();
		}
		catch(Exception e){
			System.out.println(e.getStackTrace());
		}
	}
}
