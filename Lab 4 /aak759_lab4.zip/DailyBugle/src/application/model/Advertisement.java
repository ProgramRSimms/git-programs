package application.model;
/**
 * @author Roderick Simms (aak759)
 * UTSA CS 3443 - Lab 4
 * Fall 2021
 */

/*
 * Class and class variables for ads
 */
public class Advertisement {
	String title;//0
	boolean isFullTime;//1
	String phoneNumber;//2
	String name;//3
	String date;//4
	
 
	/*
	 * //Constructor--Teaching Assistant,Full,2105554639,Dr. Henry Walton Jones Jr.,10-11-2021
	 */
	Advertisement(String title, boolean isFullTime, String phoneNumber, String name, String date){
	this.title = title;
	this.isFullTime = isFullTime;
	this.phoneNumber = phoneNumber;
	this.name = name;
	this.date = date;
	
	}

	public String getTitle() {
			// TODO Auto-generated method stub
			return title;
		}
	
	public boolean getIsFullTime() {
		// TODO Auto-generated method stub
		return isFullTime;
	}

	public String getInfo() {
		return name;
	}

	public String getPhoneNumber() {
		// TODO Auto-generated method stub
		return phoneNumber;
	}

	public String getDate() {
		// TODO Auto-generated method stub
		return date;
	}
	



}
