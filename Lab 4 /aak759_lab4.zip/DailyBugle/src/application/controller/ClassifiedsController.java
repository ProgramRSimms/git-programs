package application.controller;
/**
 * @author Roderick Simms (aak759)
 * UTSA CS 3443 - Lab 4
 * Fall 2021
 */

import java.io.IOException;

import application.model.Classifieds;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ClassifiedsController {
	@FXML
	private AnchorPane mainPane;

	@FXML
	private Button homeButton;

	@FXML
	private static Label topLeftTitle;

	@FXML
	private static Label topLeftFull;

	@FXML
	private static Label topLeftInfo;

	@FXML
	private static Label bottomLeftTitle;

	@FXML
	private static Label bottomLeftFull;

	@FXML
	private static Label bottomLeftInfo;

	@FXML
	private static Label topRightTitle;

	@FXML
	private static Label topRightFull;

	@FXML
	private static Label topRightInfo;

	@FXML
	private static Label bottomRightTitle;

	@FXML
	private static Label bottomRightFull;

	@FXML
	private static Label bottomRightInfo;


	public void handleHome(ActionEvent event) throws IOException{
		mainPane = FXMLLoader.load(getClass().getResource("Main.fxml"));
		Scene scene = new Scene(mainPane);
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(scene);
		window.show();
	}
	public static void setTopLeft() {
		// TODO Auto-generated method stub
		Classifieds ad = new Classifieds(0);
		ad.loadAds("Ads.csv");
		topLeftTitle.setText(ad.ads.get(0).getTitle());
		topLeftFull.setText(ad.ads.get(0).getIsFullTime() + "\n" + ad.ads.get(0).getPhoneNumber());
		topLeftInfo.setText("Posted by " + ad.ads.get(0).getInfo() + ", " + ad.ads.get(0).getDate());
	}

	public static void setBottomLeft() {
		// TODO Auto-generated method stub
		Classifieds ad = new Classifieds(0);
		ad.loadAds("Ads.csv");
		bottomLeftTitle.setText(ad.ads.get(1).getTitle());
		bottomLeftFull.setText(ad.ads.get(1).getIsFullTime() + "\n" + ad.ads.get(1).getPhoneNumber());
		bottomLeftInfo.setText("Posted by " + ad.ads.get(1).getInfo() + ", " + ad.ads.get(1).getDate());
	}

	public static void setBottomRight() {
		// TODO Auto-generated method stub
		Classifieds ad = new Classifieds(0);
		ad.loadAds("Ads.csv");
		bottomRightTitle.setText(ad.ads.get(3).getTitle());
		bottomRightFull.setText(ad.ads.get(3).getIsFullTime() + "\n" + ad.ads.get(3).getPhoneNumber());
		bottomRightInfo.setText("Posted by " + ad.ads.get(3).getInfo() + ", " + ad.ads.get(3).getDate());
	}

	public static void setTopRight() {
		// TODO Auto-generated method stub
		Classifieds ad = new Classifieds(0);
		ad.loadAds("Ads.csv");
		topRightTitle.setText(ad.ads.get(2).getTitle());
		topRightFull.setText(ad.ads.get(2).getIsFullTime() + "\n" + ad.ads.get(2).getPhoneNumber());
		topRightInfo.setText("Posted by " + ad.ads.get(2).getInfo() + ", " + ad.ads.get(2).getDate());
	}

}
